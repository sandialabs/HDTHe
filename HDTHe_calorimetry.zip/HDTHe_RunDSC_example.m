% HDTHe_RunDSC.m runs dscModelRunnable.m for all specified inputs.
% For best results, don't set a H isotope to zero, but just use the other isotope multiplied by 1e-4.
% This is a realistic (or optimistic) estimate of real-world gas purity, and makes the ODE solver happier.

% Calls a list of multiple runs of dsc code.  Obviously it would be nice to be able to read the list from a file.

% By Trevor Y. Cai and David B. Robinson, Sandia National Laboratories, developed between 2013 and 2015.
% See the readme file for copyright and license information.

% Each line is H2 psi, D2 psi, He psi, scan rate C/min 

Explist = [
20,30,0,2;
25,25,0,2;
30,20,0,2
];

% Run all the experiments

for i = 1:size(Explist)(1)
	printf("Inputs: HoIn: %f, DoIn: %f, HeIn: %f, ScanRate: %f\n",Explist(i,1),Explist(i,2),Explist(i,3),Explist(i,4));
	HDTHe_DSCmodel(Explist(i,1),Explist(i,2),Explist(i,3),Explist(i,4));
endfor


