% !!!! BE SURE TO RUN HDTHe_chempotential FIRST SO getEq IS IN MEMORY !!!!

% Model of differential scanning calorimetry of Pd powder in a sealed capsule connected through a small orifice to a H2/D2/He atmosphere
% This is repeatedly runnable via the RunDSCModel.m program.

% By Trevor Y. Cai and David B. Robinson, Sandia National Laboratories, Livermore, CA, developed between 2013 and 2015.
% See the readme file for copyright and license information.

% To avoid numerical crashes, it's best to not have the H isotopes strictly at zero; this is not realistic anyway.
% Natural mole fraction of D in H2 is about 1e-4. High purity D2 is about 2e-3 H. 
% Adjusting the adsorption rate constant k can also aid convergence (smaller value is more likely to converge).

% Input variables:
% HoIn, DoIn, HeIn are H2,D2,He pressure outside pan in psi.
% ScanRate in degrees C per minute

% T here is temperature, not tritium!

function tElapsed = HDTHe_DSCmodel(HoIn,DoIn,HeIn,ScanRate)

tic(); % start timer

% Global declarations
global V r k DiffG;
global R dSH dHdesH dHabsH dSD dHdesD dHabsD;
global m Tlow Thigh Ho Do Heo;
global tStep degPerSec tDyn tSwitch;
global FloCo DCo;
global guesses;
global muH2 muD2 muHD muHe DH2 DD2 DHD DHe;

% Experimental parameters that you are likely to want to change

Pdmass = 11.1;			% mass of Pd in pan, mg

TstartC = 30;			% starting scan temperature, C
TendC = 250;			% ending scan temperature, C

V = 0.000000040; 		% volume of pan, m^3
r = 0.000025;			% radius of hole, m; typical value 0.000025
L = 0.0001;			% depth of hole (pan lid thickness), m; typical value is 0.0001

% Constants with less known values

k = 0.004;  			% rate constant for hydride reaction, 1/(mol Pd*mol/m3*s)
				% - should be fast enough to maintain equilibrium
				% rate is proportional to powder surface area, which is proportional to mol Pd for a fine powder
				% Can be as high as 0.2 with numerical instability in only some cases, giving very sharp peaks.
				% 0.01 gives peak widths that are more realistic and improves numerical stability.
				% (peak width roughly matches that for 2.3 psi H2 at 2C)
				% This rate may be convolved with instrument response time
guesses = [0.05 0.7];		% initial guesses for chemical potential peak and trough values

% physical constants and conversion factors
R = 8.314;			% gas constant, J/mol*K
ZPd = 0.10642;			% molar weight of Pd, kg/mol
ZHe = 0.004;			% molar weight of He, kg/mol

CtoK = 273.15;			% convert C to K temperature (offset)
psitopa = 6895;			% convert psi to Pascals (scale factor)

% heat capacities, J/mol K
cpH2 = 28.82;			% reported for T=0 C
cpD2 = 29.2;			% I think these are from webelements.com or engineeringtoolbox.com
cpHD = 29.0;			% a guess
cpHe = 20.79;			% reported for T=25 C 
cpPd =26.0; 			% reported for T=0 C
cpD = 30.5;			% extra heat capacity in solid due to hydride, J/ K mol D
cpH = 32.6;			% from JACS 1963 paper on PdH heat capacity

% viscosities, Pa s
muH2 = 8.96e-6;			% Ref: Fundamentals of heat and mass transfer, Incropera et al., 6th ed.
muD2 = 1.193e-5;			
muHD = 1.032e-5;
muHe = 1.99e-5;					

% gas diffusion constants, m2/s
DH2 = 1.25e-4;			% Ref: Transport Phenomena, Bird, Stewart, and Lightfoot
DD2 = 8.88e-5;			
DHD = 1.03e-4;			  
DHe = 1.77e-4;
% Diffusion constants should be reduced to the Knudsen diffusion coefficient = (2/3)r*v if it is lower
% v = thermal velocity of gas = sqrt(8RT/piM)
% Gas mixture diffusion constants should be less different from each other			

% Enthalpies from Lasser and Klatt
dHdesH = 39;			% H desorption enthalpy, kJ/mol H2
dHabsH = 37.4;			% H absorption enthalpy, kJ/mol H2
dHdesD = 35.4;			% corresponding values for D2
dHabsD = 33.6;

% beta-phase heat capacity is known from Flanagan's calorimetry experiments to be lower than that of the two-phase region, and a function of x.
% - ignoring that for now.

% derived values
A = pi * r^2;			% area of hole, m^2
m = Pdmass / 1000000 / ZPd;	% moles Pd
Tlow = TstartC + CtoK;		% start temperature, K
Thigh = TendC + CtoK;		% end temperature, K



% Find concentration outside using initial pressure and temperature; c= P/RT. Now in mol/m3
% Outside temperature is assumed to always be the initial temperature

Ho = HoIn * psitopa / (R*Tlow);
Do = DoIn * psitopa / (R*Tlow);
Heo = HeIn * psitopa / (R*Tlow);

% 1 Pa / J/mol = (N/m2) mol / N m = mol/m3

% Construct flow parameters - just do crude weighted average to account for multicomponent flow
mumix = (Ho*muH2 + Do*muD2 + Heo*muHe)/(Ho + Do + Heo);
Dmix = (Ho*DH2 + Do*DD2 + Heo*DHe)/(Ho + Do + Heo);

% at small hole size or low pressure, diffusion through hole will be limited by wall collisions (Knudsen)
% this check should really be in the lsode function to capture temperature dependence correctly
if (1.5*Dmix/sqrt(8*R*Tlow/(pi*ZHe)) > r)
 Dmix = (2/3)*r*sqrt(8*R*Tlow/(pi*ZHe));
endif 
FloCo = A^2 / (8*pi*mumix*L);	% m^3/Pa s
DCo = Dmix*(A/L)*(101325/(psitopa*(HoIn + DoIn + HeIn))); % m3/s
% incorporates Bird Stewart Lightfoot pressure dependence, and assumes experiment is at near-constant pressure


% Construct temperature ramp

degPerSec = ScanRate/60;			% Increase/decrease in temperature per second
tStep = 0.1/degPerSec;				% reporting interval, seconds - this gives one point every 0.1 degrees
tDyn = (Thigh - Tlow)/degPerSec;		% time (s) for upward or downward ramp
tIso = 120;					% time (s) idling between upward ramp and downward ramp
tempStep = degPerSec * tStep;			% degrees per report interval

% In a quirk in our experiments, all the 2C measurements for 30-190 have 5 minutes iso, not 2. Adjust for this.
if(ScanRate ==2 && TendC == 190)
	tIso = 300;
endif

t = [0:tStep:((tDyn*2)+tIso)];			% array of reported time points
tSwitch = (tDyn + tIso);			% time (s) at which downward ramp starts
tSwitchIndex = floor((tDyn + tIso)/tStep);	% index at which downward ramp starts

T1 = [Tlow:tempStep:Thigh];
T2= Thigh .* ones(1,size(t)(2)-2*size(T1)(2)+1);
T3 = fliplr([Tlow:tempStep:Thigh - tempStep]);

T = [T1,T2,T3];

% Estimate initial conditions for xH and xD 

simplealpha = 2;
if (Do>0)
	alphay = simplealpha*(Ho/Do);
	Eqo(1) = 0.7 * alphay / (1 + alphay);
	Eqo(2) = 0.7 / (1 + alphay);
else
	Eqo(1) = 0.7;
	Eqo(2) = 0;
endif

% use lsode and PCT curve formula to converge on improved values

ti = [0:tStep:tIso];
Hs = lsode("g",[Ho,Heo,Do,Eqo(1),Eqo(2)],ti);

Eqo(1) = Hs(size(ti)(2),4);
Eqo(2) = Hs(size(ti)(2),5);

printf("Initial Ho: %f He: %f Do: %f H: %f D: %f\n",Ho,Heo,Do,Eqo(1),Eqo(2));

% Call lsode for the main run

Hs = lsode("f",[Ho,Heo,Do,Eqo(1),Eqo(2)],t);

%Calculate the derivatives

dH2dt = [0;diff(Hs(:,1))/tStep];
dHedt = [0;diff(Hs(:,2))/tStep];
dD2dt = [0;diff(Hs(:,3))/tStep];
dHdt = [0;diff(Hs(:,4))/tStep];
dDdt = [0;diff(Hs(:,5))/tStep];
dTdt = [0;diff(T')/tStep];

% compute power for hydride formation, through use of dH.
% apply different dH for absorption and desorption
% 10^6 factor converts kJ to J and W to mW
% factor of 2 converts mol H2 to mol H
power_des = 0.5*1000000*m*(dHdesH*dHdt(1:tSwitchIndex) + dHdesD*dDdt(1:tSwitchIndex));
power_abs = 0.5*1000000*m*(dHabsH*dHdt(tSwitchIndex+1:rows(dHdt)) + dHabsD*dDdt(tSwitchIndex+1:rows(dDdt)));

power_hydride = [power_des;power_abs];

% Calculate power associated with heating material in the pan

power_heatcap = -1000*(V*cpH2*Hs(:,1) + V*cpHe*Hs(:,2) + V*cpD2*Hs(:,3) + m*cpPd*ones(size(Hs(:,1))) + m*cpH*Hs(:,4) + m*cpD*Hs(:,5)).*dTdt;

% Calculate power associated with heating of incoming gas
% the first max sum is a way to just get the incoming gas flow terms from the H2 ODE
% power is in mW

power_ingas = -1000*(cpH2*max(V*dH2dt + 0.5*m*dHdt,0) + cpD2*max(V*dD2dt + 0.5*m*dDdt,0) + cpHe*max(V*dHedt,0)).*(T'-Tlow);

% then add up these power terms

power = power_hydride + power_heatcap + power_ingas;

Hflow = V*dH2dt+0.5*m*dHdt;
Dflow = V*dD2dt+0.5*m*dDdt;
Heflow = V*dHedt;

% report calculation time
tElapsed = toc()

% save data to file
savetime = strftime("%y%m%d%H%M%S",localtime(time()));
filename = strcat("dscModel_",num2str(floor(HoIn)),"_",num2str(floor(DoIn)),"_",num2str(floor(HeIn)),"_",num2str(floor(ScanRate)),"_",savetime,".csv");
dlmwrite(filename,[
	"HoIn (psi),",num2str(HoIn);
	"HeIn (psi),",num2str(HeIn);
	"DoIn (psi),",num2str(DoIn);
	"Scan rate (C/min),",num2str(ScanRate);
	"Pd mass (mg),",num2str(Pdmass);
	"Pan vol (uL),",num2str(V*1000000000);
	"Hole diameter (um),",num2str(r*2000000);
	"Flow coefficient (m3/Pa s),",num2str(FloCo);
	"Diffusion constant (cm2/s),",num2str(Dmix*10000);
	"Hydride rate constant(1/(mol s)),",num2str(k);
	"t (s),","H2+HD/2 (mol/m3),He (mol/m3),D2+HD/2 (mol/m3),H/Pd,D/Pd,Temp (C),total power (mW),hydride power (mW),heatcap power (mW),gas preheat power (mW),Hflow,Dflow,Heflow"
	],"");
dlmwrite(filename,[t',Hs,T'.-CtoK,power,power_hydride,power_heatcap,power_ingas,Hflow,Dflow,Heflow],"-append");

endfunction

% g() is a simple version of f, used for an initial lsode run to converge on the proper initial conditions for xH and xD without messing up the initial gas concentrations.

function xdot = g(x,t)

	global V r Ho Heo Do k m Tlow R guesses;

	T = Tlow;

	Eq = getEq(x(4)+x(5),x(4)/(x(4)+x(5)),T,guesses,0);
	guesses = [Eq(1) Eq(2)];
	HDeq = 10^Eq(4);
	Heq = (10^Eq(3) + 0.5*HDeq)*101325/(R*T);
	Deq = (10^Eq(5) + 0.5*HDeq)*101325/(R*T);
	
	% printf("t: %f T: %f Heq: %f Deq: %f\n",t,T,Heq,Deq);
	% x'

	xdot(1) = 0;
	xdot(2) = 0;
	xdot(3) = 0;
	xdot(4) = 0.1*(x(1)-Heq);
	xdot(5) = 0.1*(x(3)-Deq);

endfunction

% f() is required for lsode; this is the system of differential equations that must be solved.

function xdot = f(x,t)

	global V r FloCo DCo Ho Heo Do k m degPerSec Tlow Thigh tDyn tSwitch R guesses;

%	printf("t requested: %f\n",t);

	%Calculate T value and desorption/absorption status.
	if(t<=tSwitch)
		isDes = 1;
		if(t<tDyn)
			T = (t*degPerSec) + Tlow;
		else
			T = Thigh;
		endif
	else
		isDes = 0;
		T = Thigh - ((t-tSwitch)*degPerSec);
	endif		
	
	Pdiff = R*Tlow*(Ho + Do + Heo) - R*T*(x(1) + x(2) + x(3));

	Eq = getEq(x(4)+x(5),x(4)/(x(4)+x(5)),T,guesses,1-isDes);
	guesses = [Eq(1) Eq(2)];
	HDeq = 10^Eq(4);
	Heq = (10^Eq(3) + 0.5*HDeq)*101325/(R*T);
	Deq = (10^Eq(5) + 0.5*HDeq)*101325/(R*T);

	FloCoNow = FloCo*(T/273)^-0.68;  % Temp dependence of 1/viscosity from FM White, Viscous Fluid Flow
	DCoNow = DCo*(T/273)^1.823;	% Temp dependence from Bird Stewart Lightfoot
	
	% printf("t: %f T: %f Heq: %f Deq: %f\n",t,T,Heq,Deq);
	% x'

	if(Pdiff>0)
		xdot(1) = ((FloCoNow * Ho  * Pdiff) + (DCoNow*(Ho-x(1))) - k*m*(x(1)-Heq))/V;
		xdot(2) = ((FloCoNow * Heo  * Pdiff) + (DCoNow*(Heo-x(2))))/V;		
		xdot(3) = ((FloCoNow * Do  * Pdiff) + (DCoNow*(Do-x(3))) - k*m*(x(3)-Deq))/V;		
	else
		xdot(1) = ((FloCoNow * x(1) * Pdiff) + (DCoNow*(Ho-x(1))) - k*m*(x(1)-Heq))/V;
		xdot(2) = ((FloCoNow * x(2) * Pdiff) + (DCoNow*(Heo-x(2))))/V;
		xdot(3) = ((FloCoNow * x(3) * Pdiff) + (DCoNow*(Do-x(3))) - k*m*(x(3)-Deq))/V;
	endif
	xdot(4) = 2*k*(x(1)-Heq);
	xdot(5) = 2*k*(x(3)-Deq);

endfunction
