% !!!! BE SURE TO RUN HDTHe_chempotential FIRST !!!!

% This script generates families of PCT curves and chemical potential plots for a given temperature and solid-phase isotopic ratio.

% By David B. Robinson, Sandia National Laboratories, developed between 2013 and 2015.
% See the readme file for copyright and license information.

% Function getPlateau calculates Laesser and Klatt-type plateau pressure prediction
% for temperature input and boolean variable indicating whether absorption (0) or desorption (1) is taking place.
% Plateau is reported in atm.
% The plateau is the gas partial pressure of hydrogen+deuterium at which Pd undergoes a phase transition between empty and full
% This function is mainly intended for use with pure gases. It returns a Raoult's law guess for mixed isotopologues.

% initialize arrays
logP = linspace(0,0,999);	% total pressure
logPHH = linspace(0,0,999);	% partial pressures
logPHD = linspace(0,0,999);
logPDD = linspace(0,0,999);
Hterm1 = linspace(0,0,999);	% terms in chemical potential formulae, retained for diagnostic purposes
Hterm2 = linspace(0,0,999);
Hterm3 = linspace(0,0,999);
Hterm4 = linspace(0,0,999);
Hterm5 = linspace(0,0,999);
Dterm1 = linspace(0,0,999);
Dterm2 = linspace(0,0,999);
Dterm3 = linspace(0,0,999);
Dterm4 = linspace(0,0,999);
Dterm5 = linspace(0,0,999);
HDterm5 = linspace(0,0,999);
mu_solidH = linspace(0,0,999);
mu_solidD = linspace(0,0,999);
mu0_gasHH = linspace(0,0,999);
mu0_gasDD = linspace(0,0,999);
mu0_gasHD = linspace(0,0,999);
QHD = linspace(0,0,999);	% HD gas-phase reaction quotient, to check to see if HD equilibrium is maintained
sepfactor = linspace(0,0,999);  % separation factor: gas phase D/H divided by solid phase D/H
PCTabs = linspace(0,0,999);	% PCT curves incorporating plateau pressures
PCTdes = linspace(0,0,999);
x = linspace(0.001,0.999,999);	% fraction of occupied sites in the solid phase
Temparray = [ ];		% used for storing multiple PCT isotherms at several temperatures
PCTabsarray = [ ];
PCTdesarray = [ ];
reportarray = [ ];

StartTemp = 223; % temperature, K
deltaT = 50;     % increment for temperature loop
Tpoints = 8;     % temperature points in loop
Temp = StartTemp;

xH = 0.7;	% isotopic fraction H in solid - these should sum to 1
xD = 1.0-xH;	% ignoring T for now

H = 1;		% indices used in function calls
D = 2;

printf("Temp,LKabs,abs,LKdes,des,peak,trough\n");

for y = 1:Tpoints	% temperature loop

logPmax = -100;
logPmin = 100;
afterpeak = false;
aftertrough = false;
peakz = 1;
troughz = 999;
LKabsplat = log10(getPlateau(xH,xD,0,Temp,0));
LKdesplat = log10(getPlateau(xH,xD,0,Temp,1));
LKabsplatline = linspace(LKabsplat,LKabsplat,999);
LKdesplatline = linspace(LKdesplat,LKdesplat,999);

for z = 1:999	% this loop computes pressures and chemical potential terms as a function of x for a given temperature

 % compute quantities associated with H
 Hterm1(z) = mu0_solid(H,Temp);
 Hterm2(z) = R*Temp*log(xH*x(z)/(1.0-x(z)));
 Hterm3(z) = 0;
 Hterm4(z) = muEstar(x(z),Temp);
 mu_solidH(z) = Hterm1(z) + Hterm2(z) + Hterm3(z) + Hterm4(z);
 mu0_gasHH(z) = mu0_gas(H,H,Temp);
 Hterm5(z) = mu0_gasHH(z)/2;
 logPHH(z) = (2*mu_solidH(z) - mu0_gasHH(z))/(2.303*R*Temp);

 % compute quantities associated with D
 Dterm1(z) = mu0_solid(D,Temp);
 Dterm2(z) = R*Temp*log(xD*x(z)/(1.0-x(z)));
 Dterm3(z) = 0;
 Dterm4(z) = muEstar(x(z),Temp);
 mu_solidD(z) = Dterm1(z) + Dterm2(z) + Dterm3(z) + Dterm4(z);
 mu0_gasDD(z) = mu0_gas(D,D,Temp);
 Dterm5(z) = mu0_gasDD(z)/2;
 logPDD(z) = (2*mu_solidD(z) - mu0_gasDD(z))/(2.303*R*Temp);

 % compute quantities associated with HD
 mu0_gasHD(z) = mu0_gas(H,D,Temp);
 HDterm5(z) = mu0_gasHD(z)/2;
 logPHD(z) = (mu_solidH(z) + mu_solidD(z) - mu0_gasHD(z))/(2.303*R*Temp);

 % compute overall quantitities of interest
 logP(z) = log10(10^logPHH(z) + 10^logPDD(z) + 10^logPHD(z));
 QHD(z) = (10^logPHD(z))^2/(10^logPHH(z)*10^logPDD(z));
 if (xH>0)
  sepfactor(z) = ((10^logPDD(z) + 0.5*(10^logPHD(z)))/(10^logPHH(z) + 0.5*(10^logPHD(z))))/(xD/xH);
 endif 

 % find positions of peak and trough in logP, if present
 if(z==1)
  logPmax = max(logP(z),logPmax);
 else
  if(!afterpeak)
   logPmax = max(logP(z),logPmax);
   if(logP(z)<logP(z-1))
    afterpeak = true;
    peakz = z-1;
   endif
  else
   if(!aftertrough)
    logPmin = min(logP(z),logPmin);
    if(logP(z)>logP(z-1))
     aftertrough = true;
     troughz = z-1;
    endif
   endif % !aftertrough
  endif % !afterpeak
 endif % z==1

endfor % z


if(afterpeak)

 % new fits to our van't Hoff data
 desplat = logP(troughz) + (516.88/Temp)-0.8671;
 absplat = logP(troughz) + (756.09/Temp)-1.2764;
 
 absplat = max(logP(troughz),absplat);
 desplat = max(logP(troughz),desplat);
 absplat = min(logP(peakz),absplat);
 desplat = min(logP(peakz),desplat); 
 
 absplatline = linspace(absplat,absplat,999);
 desplatline = linspace(desplat,desplat,999);


% trim logP curve to plateau pressures at appropriate x values to create PCT curve

 for z=1:peakz
  PCTabs(z) = min(logP(z),absplat);
  PCTdes(z) = min(logP(z),desplat);
 endfor
 for z = (peakz+1):troughz
  PCTabs(z) = absplat;
  PCTdes(z) = desplat;
 endfor
 for z = (troughz+1):999
  PCTabs(z) = max(logP(z),absplat);
  PCTdes(z) = max(logP(z),desplat);
 endfor

else % not afterpeak

 PCTabs = logP;
 PCTdes = logP;
 absplatline = linspace(LKabsplat,LKabsplat,999);
 desplatline = linspace(LKdesplat,LKdesplat,999);

endif

Temparray = [ Temparray, Temp-273 ];
PCTabsarray = [ PCTabsarray, PCTabs' ];
PCTdesarray = [ PCTdesarray, PCTdes' ];

printf("%e,%e,%e,%e,%e,%e,%e\n",Temp,LKabsplat,absplat,LKdesplat,desplat,logP(peakz),logP(troughz));

Temp = Temp + deltaT;

endfor % y

Temp = Temp - deltaT;

% make plot of last curve and save data

h=figure(1);

plot(x,logP,x,logPHH,x,logPDD,x,logPHD,x,absplatline,x,desplatline,x,LKabsplatline,x,LKdesplatline);
title(strcat("H:D in Pd = ",num2str(100*xH,'%d'),":",num2str(100*xD,'%d')," Temperature = ",num2str(Temp-273,'%d')," C"));
legend("P","PHH","PDD","PHD","abs","des","LKabs","LKdes","location","southeast");
xlabel("(H+D)/Pd");
ylabel("log10 (P/1 atm)");
axis([0 0.8 -6 3]);
FS = findall(h,'-property','FontSize');
set(FS,'FontSize',14);

savetime = strftime("%y%m%d%H%M%S",localtime(time()));
PCTname = strcat("PCTcurves_",savetime,".csv");
muname = strcat("logP_",savetime,".csv");
muplotname = strcat("logPplot_",savetime,".png");
% print(muplotname,"-dpng");

% The first writes the PCT curves, and the second writes the chemical potential plot for the last temperature.
dlmwrite(PCTname,[0,Temparray;cat(1,x',flipud(x')),cat(1,PCTabsarray,flipud(PCTdesarray))]);
dlmwrite(muname,["x,Ptotal,PHH,PDD,PHD,abs_plat,des_plat,abs_plat_LK,des_plat_LK"],"");
dlmwrite(muname,[x',logP',logPHH',logPDD',logPHD',absplatline',desplatline',LKabsplatline',LKdesplatline'],"-append");

% plot(x,QHD,x,sepfactor);

