HDTHe_calorimetry

These Octave scripts generate predicted results of differential scanning calorimetry experiments for samples of palladium in a perforated capsule in an atmosphere containing a mixture of hydrogen isotopologues and helium.  They can also be used to predict the results of absorption-desorption experiments at constant temperature and solid-phase isotopic ratio.  Tritium is not fully implemented in the scripts, but mixtures of tritium and one other isotope could be accounted for through straightforward modifications.

Authors:
David B. Robinson and Trevor Y. Cai
Energy Nanomaterials Department
Sandia National Laboratories
Livermore, CA USA

The scripts were developed using GNU Octave 3.6.4, and may function properly using other Octave versions.

To use the scripts, start Octave, and use the "cd" command to change the working directory to the location of the scripts.

Enter the command "HDTHe_chempotential" to load functions required for the other scripts.

To generate simulations of DSC experiments, edit the "HDTHe_RunDSC_example.m" script using a text editor.  Change the parameters in the input array to the desired values, according to the explanatory comments in that script.  Save the script under a new file name such as "HDTHe_RunDSC.m" and then enter the file name without the extension in the Octave command window, such as "HDTHe_RunDSC".  The output will be generated as comma-delimited text files.

If the solver crashes, consider editing the value of the parameter "k" in the script "HDTHe_DSCmodel.m".

To generate simulations of PCT curves, edit the "HDTHe_PCTplot.m" script using a text editor.  Change the values of the temperature loop parameters (StartTemp, deltaT, Tpoints) and the value of xH, the isotopic fraction H in the solid, to desired values.  Save the script and enter "HDTHe_PCTplot" in the Octave command window.  The output will be generated as comma-delimited text files.  One file contains the PCT curves, and another contains the partial pressures and plateau pressures for the last temperature in the loop.  For PCT curves, the first column contains the ratio of hydrogen isotopes to metal atoms in the solid, and subsequent columns are the equilibrium pressures at the temperature indicated in the first row.  For the partial/plateau pressure file, the columns are the ratio of hydrogen isotopes to metal atoms in the solid in the first column, and then the base-10 log of various pressures: the total pressure, the H2 partial pressure, the D2 partial pressure, the HD partial pressure, the adsorption plateau pressure, the desorption plateau pressure, the adsorption plateau pressure given by an empirical fit, and the desorption plateau pressure given by an empirical fit.  The emprical fits are only meaningful for pure gases.

*********************************
Copyright 2016 Sandia Corporation

Under the terms of Contract DE-AC04-94AL85000 with Sandia Corporation, the U.S. Government retains certain rights in this software.

Redistribution and use in source and binary forms, with or without modification, are permitted provided that the following conditions are
met:

1. Redistributions of source code must retain the above copyright notice, this list of conditions and the following disclaimer.

2. Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the following disclaimer in the documentation and/or other materials provided with the distribution.

3. Neither the name of the Corporation nor the names of the contributors may be used to endorse or promote products derived from this software without specific prior written permission.

This software is provided by Sandia Corporation "as is" and any express or implied warranties, including, but not limited to, the implied warranties of merchantability and fitness for a particular purpose are disclaimed. In no event shall Sandia Corporation or the contributors be liable for any direct, indirect, incidental, special, exemplary, or consequential damages (including, but not limited to, procurement of substitute goods or services; loss of use, data, or profits; or business interruption) however caused and on any theory of liability, whether in contract, strict liability, or tort (including negligence or otherwise) arising in any way out of the use of this software, even if advised or the possibility of such damage.
*********************************
