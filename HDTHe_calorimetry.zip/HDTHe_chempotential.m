% This script implements the PCT model in:
% Flanagan, Kuji, and Oates J Phys F 1985 (FKO)
% Oates, Lasser, Kuji, and Flanagan J Phys Chem Solids 1986 (OLKF)
% Lasser and Powell 1986 (LP) gas parameters
% with comparison to Lasser and Klatt (LK)-style empirical plateau pressures

% David B. Robinson, Sandia National Laboratories, Livermore, CA, Fall 2013
% Helpful conversations about chemical potentials with Bill Wolfer (also at Sandia) are acknowledged.
% See the readme file for copyright and license information.

% basic equation is mu_gas = 2mu_solid at equilibrium
% mu_gas = mu0_gas + RTln(P/1 atm)
% P = 1 atm * exp ((2mu_solid - mu0_gas)/RT)
% mu_solid = mu0_solid + RTln(x/(1-x)) + muEV + muEstar
% x is H-to-metal ratio (or D or T to metal)
% where muEV captures the vibrational isotope and x dependence
%  - the model in OLKF is problematic, and does not improve fits to data, so it is ignored here
%  - it also removes dependence of separation factor on total loading (H+D+T)/M, which is convenient
% muEstar captures all other x dependence, and is isotope independent (electronic, elastic, etc)
% muEstar is the main contribution to the upper limit on capacity
% - using fit in FKO that ignores muEV
% LP defines mu0_gas as in the function below

% new part: combining to allow for mixed isotopes, for each ij:
% mu_gasii + mu_gasjj = 2mu_gasij where mu_gasij is defined by LP 
% -- the gas equations are redundant with the gas-solid equations
% mu_gasij = mu_solidi + mu_solidj
% mu_solidi = mu0_solid + RTln(xi/(1-sum(xi)) + muEV + mEstar
% for muEV and muEstar, x becomes sum(xi)
% solve for Pij:
% Pij = 1 atm * exp ((mu_solidi + mu_solidj - mu0_gasij)/RT)
% sum(Pij, i<=j) = P (i.e., sum of partial pressures is total pressure)
% for 2 isotopes, there are 5 components to determine, 3 gas-solid equations, and a total pressure equation.
% Typically we will fix the gas- or solid-phase H:D ratio and sweep the pressure or temperature to see how the gas-phase H:D ratio changes. 
% Plateau pressures were determined by using empirical scaling factors between trough and peak
% to make the predicted pressure more closely match the pure isotope plateau pressures according to LK.
% This was compared to a Maxwell construction, a better established method to identify phase transitions.
% The Maxwell construction does not provide a better match to experimental values, and is more computationally intensive,
% requiring calculation of the whole curve any time one wants to know just the plateau pressure.
% It is easier to determine just the trough and peak values. 

% HD equilibrium constant comes out well.

R = 8.314; % ideal gas constant in J/mol K

function m0g = mu0_gas(i,j,Temp)

 R = 8.314; % ideal gas constant in J/mol K

 % from LP
 % These parameters are for gas-phase mu0, for a given diatomic species ij (H2, HD, D2, etc.)
 % indices are H=1, D=2, T=3

 L = [ 4.293e-4, 2.093e-3, 3.614e-3; 2.093e-3, 2.406e-3, 8.041e-3; 3.614e-3, 8.041e-3, 6.582e-3 ];
 J = [ 5986, 5225, 4940; 5225, 4307, 3948; 4940, 3948, 3548 ];
 M = [ 51994.9, 52402.2, 52552.1; 52402.2, 52888.2, 53076.1; 52552.1, 53076.1, 53285.6 ];
 D0 = [ 51966.5, 52380.8, 52532.9; 52380.8, 52873.9, 53064.1; 52532.9, 53064.1, 53276.0 ];
 B0 = [ 85.348, 64.269, 57.187; 64.269, 43.027, 35.927; 57.187, 35.927, 28.819 ];

 m0g = -R*Temp*log((L(i,j)*Temp^3.5)/(1-exp(-J(i,j)/Temp)))-R*M(i,j);

 % The log numerator captures the temperature dependence of the translational and rotational partition functions.
 % The log denominator captures the temperature dependence of the vibrational partition function.
 % M is mostly the bond dissociation energy D0; the reference state here is the barely dissociated diatomic gas.
 % Other non-temperature-dependent effects are lumped into M and L.
 % as a reference point, the textbook bond dissociation energy for H2 is 436 kJ/mol.
 % This function varies from about 450 to 500 kJ/mol for H2, or 460 to 530 for T2, between 200 and 600 C.

endfunction

function m0s = mu0_solid(i,Temp)

 % from OLKF

 R = 8.314; % ideal gas constant in J/mol K

 A = [ 1.981, 1.933, 1.912 ];
 B = [ 768.0, 664.0, 617.9 ];
 C = [ 800.0, 565.7, 461.9 ];
 E = [ 28145.0, 28175.4, 28188.9 ];
 U = [ 26945.0, 27326.9, 27496.0 ];

 zeta = 1 + A(i)*exp(-B(i)/Temp);
 xi = (1 - exp(-C(i)/Temp))^-3;

 m0s = -R*Temp*log(zeta*xi)-R*U(i);

endfunction

function mstar = muEstar(x,Temp)

 % muEstar is the electronic/elastic/misc contribution to the chemical potential in the solid, taken to be isotope-independent.
 % This function was apparently a fit by OLKF to alpha- and beta-phase PCT data, having subtracted off other components,
 % with the additional constraint that the function must go to zero at x=0.
 % It is the dominant effect in the beta phase, but approximately negligible in the alpha phase.
 % The method to obtain plateau pressures used here works better with the FKO values.
 % OLKF may give better behavior in vicinity of critical point. For FKO, it is at x = 0.274 and T = 606 K.

 % OLKF version, from which they have apparently subtracted out their estimate of muEV:

 % mstar = (-67466.8+65.4*Temp)*x + (64634.49-79.31*Temp)*x*x + (24355.39-13.03*Temp)*x*x*x;

 % FKO J. Phys. F 1985:

 mstar = (-68555+51.157*Temp)*x + (59308-71.9*Temp)*x*x + (30497-23.667*Temp)*x*x*x;

endfunction

function lp = logP(x,Hfrac,Temp)
% ignoring xT for now

 R = 8.314; % ideal gas constant in J/mol K

 xH = Hfrac*x;
 xD = (1.0 - Hfrac)*x;
 xtot = x;

 H = 1;		% indices used in function calls
 D = 2;

 mu_solidH = mu0_solid(H,Temp) + R*Temp*log(xH/(1.0-xtot)) + muEstar(xtot,Temp);
 logPHH = (2*mu_solidH - mu0_gas(H,H,Temp))/(2.303*R*Temp);

 mu_solidD = mu0_solid(D,Temp) + R*Temp*log(xD/(1.0-xtot)) + muEstar(xtot,Temp);
 logPDD = (2*mu_solidD - mu0_gas(D,D,Temp))/(2.303*R*Temp);

 logPHD = (mu_solidH + mu_solidD - mu0_gas(H,D,Temp))/(2.303*R*Temp);

 logP = log10(10^logPHH + 10^logPDD + 10^logPHD);

 lp = [logPHH logPHD logPDD logP];

endfunction

function fp = findpeaktrough(guess,Hfrac,Temp)
% use newton's method to find peak or trough in total pressure
% the genuine method should have 0.5 as the coefficient on deltax, but a lower value is less likely to overshoot, and still gets there.
% component 4 returned by the logP function is total pressure

 deltax = 0.001;
 newguess = guess;
 oldguess = 99;
 sanitycheck = 0;

 while ((abs(newguess - oldguess) > deltax) && sanitycheck < 1000)
  sanitycheck = sanitycheck + 1;
  oldguess = newguess;
  lpplus = logP(oldguess+deltax,Hfrac,Temp)(4);
  lpminus = logP(oldguess-deltax,Hfrac,Temp)(4);
  lp0 = logP(oldguess,Hfrac,Temp);
  newguess = oldguess - 0.25*deltax*(lpplus - lpminus)/(lpplus + lpminus - 2*lp0(4));
  if ((newguess < deltax) || newguess > 1) newguess = oldguess; endif;
 endwhile

 fp = [newguess lp0(4)];

endfunction

function gEq = getEq(x,Hfrac,Temp,guesses,absnotdes)

 R = 8.314; % ideal gas constant in J/mol K

 peak = findpeaktrough(guesses(1),Hfrac,Temp);
 trough = findpeaktrough(guesses(2),Hfrac,Temp);

 % An earlier fit to LK experimental data
 % plateau = trough(2) + 0.55*(peak(2)-trough(2));
 % if(absnotdes)
 %  % add enthalpy difference from LK, or cap at logP peak
 %  plateau = min(plateau + 800/(R*Temp),peak(2));
 % endif

 % new fits to our pure-gas data
 plateau = trough(2) + (516.88/Temp)-0.8671;
 if(absnotdes)
  plateau = trough(2) + (756.09/Temp)-1.2764;
 endif

 plateau = max(trough(2),plateau);
 plateau = min(peak(2),plateau);

 lp0 = logP(x,Hfrac,Temp);

 pp = lp0.-lp0(4);

 if (x<peak(1))
  tp = min(plateau,lp0(4));
 elseif (x<trough(1))
  tp = plateau;
 else
  tp = max(plateau,lp0(4));
 endif

 pp = tp.+pp;
 gEq = [peak(1) trough(1) pp];

endfunction

function Plateau = getPlateau(xH,xD,xT,Temp,isDes)

% plateau pressure formula parameters from Laesser and Klatt (LK) over the range 30-180 C

 R = 8.314; % ideal gas constant in J/mol K

 dSdesH = 92.5;		% H des prefactor (LK pseudo entropy), J/K mol H2
 dSabsH = 92.5;		% H abs prefactor (LK pseudo entropy), J/K mol H2

 dHdesH = 39.0;		% H desorption enthalpy, kJ/mol H2
 dHabsH = 37.4;		% H absorption enthalpy, kJ/mol H2

 dSdesD = 93.3;		% corresponding values for D2
 dSabsD = 93.3;		

 dHdesD = 35.4;
 dHabsD = 33.6;

 dSdesT = 91.7;		% corresponding values for T2
 dSabsT = 91.7;
 dHdesT = 33.3;
 dHabsT = 31.6;		% LK did not report abs values, so educated guesses were made.

% In this version, override L-K with fits to a Van't Hoff plot for our own Pd powder

dSdesH = 96.8;		% H des prefactor (LK pseudo entropy), J/K mol H2
dSabsH = 85.6;		% H abs prefactor (LK pseudo entropy), J/K mol H2

dHdesH = 40.9;		% H desorption enthalpy, kJ/mol H2
dHabsH = 34.9;		% H absorption enthalpy, kJ/mol H2

dSdesD = 95.3;		% corresponding values for D2
dSabsD = 87.9;		

dHdesD = 36.1;
dHabsD = 31.9;


 if(isDes)
	Hplat = exp((dSdesH/R) - (1000*dHdesH/R/Temp));
	Dplat = exp((dSdesD/R) - (1000*dHdesD/R/Temp));
	Tplat = exp((dSdesT/R) - (1000*dHdesT/R/Temp));
 else
	Hplat = exp((dSabsH/R) - (1000*dHabsH/R/Temp));
	Dplat = exp((dSabsD/R) - (1000*dHabsD/R/Temp));
	Tplat = exp((dSabsT/R) - (1000*dHabsT/R/Temp));
 endif

 Plateau = ((xH*Hplat+xD*Dplat+xT*Tplat)/(xH+xD+xT)); % in atm; mult by (10^5/R)/T to report as mol/m3

endfunction

printf("HDTHe chemical potential functions loaded.\n");
printf("See the readme file for copyright and license information.\n");
